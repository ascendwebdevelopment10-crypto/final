// Opt-out list. Honored on every run. Two sources, merged:
//   1. local suppression.txt (one email per line)
//   2. the deployed cloud list (bounces, complaints, one-click unsubscribes)
import { readFileSync, existsSync, appendFileSync } from "node:fs";

const FILE = "suppression.txt";

function loadLocal() {
  if (!existsSync(FILE)) return [];
  return readFileSync(FILE, "utf8").split(/\r?\n/).map((l) => l.trim().toLowerCase()).filter(Boolean);
}

// Pull the live opt-out list from the deployed Vercel service, if configured.
async function loadRemote(cfg) {
  if (!cfg.suppressApiUrl || !cfg.suppressApiSecret) return [];
  try {
    const res = await fetch(`${cfg.suppressApiUrl}?key=${encodeURIComponent(cfg.suppressApiSecret)}`);
    if (!res.ok) throw new Error(`${res.status}`);
    const data = await res.json();
    return (data.emails || []).map((e) => e.toLowerCase());
  } catch (e) {
    console.warn(`  ! Could not reach cloud suppression list (${e.message}). Using local file only.`);
    return [];
  }
}

export async function loadSuppressed(cfg) {
  const set = new Set(loadLocal());
  for (const e of await loadRemote(cfg)) set.add(e);
  return set;
}

export function suppress(email) {
  appendFileSync(FILE, email.toLowerCase() + "\n");
}
