// Sends through Resend and FORCES CAN-SPAM compliance into every message:
// honest From, working one-click unsubscribe, and a physical mailing address.
import { createHmac } from "node:crypto";

function escapeHtml(s) {
  return String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}

// Signed unsubscribe link to the deployed page. Falls back to mailto if no URL set.
// Must match lib/sign.js in the Vercel app (same secret).
function unsubLink(cfg, lead) {
  if (!cfg.unsubscribeUrl) {
    return { url: `mailto:${cfg.unsubscribeEmail}?subject=${encodeURIComponent("UNSUBSCRIBE " + lead.email)}`, oneClick: false };
  }
  const token = cfg.unsubscribeSecret
    ? createHmac("sha256", cfg.unsubscribeSecret).update(lead.email.toLowerCase().trim()).digest("base64url").slice(0, 16)
    : "";
  const url = `${cfg.unsubscribeUrl}?e=${encodeURIComponent(lead.email)}${token ? `&t=${token}` : ""}`;
  return { url, oneClick: true };
}

function complianceFooter(cfg, lead) {
  const { url, oneClick } = unsubLink(cfg, lead);
  const optOut = oneClick
    ? `Not interested? Unsubscribe: ${url}`
    : `Not interested? Reply "unsubscribe" or email ${cfg.unsubscribeEmail} and you'll never hear from us again.`;
  return `\n\n--\n${[
    `You received this because your role at ${lead.company || "your company"} matched our outreach.`,
    optOut,
    `${cfg.companyName}, ${cfg.physicalAddress}`,
  ].join("\n")}`;
}

function toHtml(body, cfg, lead) {
  const { url } = unsubLink(cfg, lead);
  const paras = body.split(/\n{2,}/).map((p) => `<p>${escapeHtml(p).replace(/\n/g, "<br>")}</p>`).join("");
  return (
    `<div style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;font-size:15px;line-height:1.5;color:#222">` +
    paras +
    `<hr style="border:none;border-top:1px solid #eee;margin:20px 0">` +
    `<p style="font-size:12px;color:#888">` +
    `You received this because your role at ${escapeHtml(lead.company || "your company")} matched our outreach. ` +
    `<a href="${escapeHtml(url)}" style="color:#888">Unsubscribe</a> and you'll never hear from us again.<br>` +
    `${escapeHtml(cfg.companyName)}, ${escapeHtml(cfg.physicalAddress)}` +
    `</p></div>`
  );
}

export async function sendEmail(cfg, lead, subject, body) {
  const { url, oneClick } = unsubLink(cfg, lead);
  // Prefer an https one-click header (Gmail/Yahoo bulk-sender requirement); else mailto.
  const listUnsub = oneClick ? `<${url}>` : url.replace(/^mailto:/, "<mailto:") + ">";
  const headers = { "List-Unsubscribe": listUnsub };
  if (oneClick) headers["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click";

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${cfg.resendKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: cfg.from,
      to: [lead.email],
      reply_to: cfg.replyTo,
      subject,
      text: body + complianceFooter(cfg, lead),
      html: toHtml(body, cfg, lead),
      headers,
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Resend ${res.status}: ${JSON.stringify(data)}`);
  return data.id;
}

// Exposed so dry-run can show the exact email that WOULD go out, footer and all.
export function previewText(cfg, lead, body) {
  return body + complianceFooter(cfg, lead);
}
