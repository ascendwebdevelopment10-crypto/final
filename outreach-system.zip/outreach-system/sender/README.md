# Outreach Engine

Pulls real leads from Apollo, writes a personalized cold email for each one with Claude,
and sends them through Resend — with CAN-SPAM compliance built in and a full report after every run.

It runs in **dry-run by default**: it shows you the exact emails it would send, sends nothing,
and only sends for real when you add `--send`.

## What it does

1. **Pulls leads** from Apollo by title / keyword / location, then enriches them for verified work emails.
2. **Writes each email** with Claude, personalized to that person's company and signal.
3. **Sends** through Resend, with a working unsubscribe link and your physical address on every message.
4. **Reports** every result to a timestamped CSV plus a console summary.

## What it does NOT do

- **No SMS / texting.** Cold-texting people who never opted in violates the US TCPA
  ($500–$1,500 per message). This tool is email-only by design. If you have an opted-in
  contact list and want SMS to *those* people, that's a different, consent-based build.
- It doesn't bypass Apollo credits, email verification, or domain reputation. There are no shortcuts there.

## Setup

1. **Install nothing.** Needs only Node.js 18+ (uses built-in `fetch`). Check with `node --version`.
2. **Copy the config:** `cp .env.example .env`, then fill in `.env`:
   - `APOLLO_API_KEY` — a *master* key (Apollo dashboard → Settings → API Keys).
   - `ANTHROPIC_API_KEY` — console.anthropic.com → API Keys.
   - `RESEND_API_KEY` — resend.com → API Keys. **You must verify your sending domain first**, or delivery fails.
   - `FROM`, `REPLY_TO` — must use your verified domain.
   - `COMPANY_NAME`, `PHYSICAL_ADDRESS`, `UNSUBSCRIBE_EMAIL` — **legally required** in every email. The app refuses to send live without them.
   - `TARGET_TITLES`, `TARGET_KEYWORDS`, `TARGET_LOCATIONS` — who Apollo pulls.
   - `MAX_LEADS`, `SEND_DELAY_SECONDS` — safety limits.

## Usage

```bash
# 1. DRY RUN — pulls leads, writes emails, prints them. Sends nothing.
node index.js

# 2. Read the previews and the report CSV. Happy with them?

# 3. SEND FOR REAL.
node index.js --send
```

Start with `MAX_LEADS=5` and a slow `SEND_DELAY_SECONDS` until you trust your copy and your
domain is warmed up. Sending a big cold volume from a cold domain is the fastest way to land in spam.

## Handling replies and opt-outs

- Anyone who asks out goes in **`suppression.txt`** (one email per line). It's checked on every run; suppressed addresses are never contacted again. Add people the moment they reply "unsubscribe."
- To catch replies and bounces automatically, point a Resend webhook at an endpoint you host and append complainers/bouncers to `suppression.txt`. (Not included here — it needs a server.)

## Staying legal (read this)

Cold *email* is allowed in the US under CAN-SPAM if you: identify yourself honestly, include a
real physical postal address, give a working opt-out, and honor opt-outs promptly. This tool does
all of that automatically — don't strip it out. Rules differ elsewhere (e.g. CASL in Canada, GDPR/
PECR in the EU/UK can require a lawful basis or consent). This isn't legal advice; check what
applies to the people you're emailing.

## Files

```
index.js            orchestrator (dry-run default, reporting)
src/apollo.js       lead search + enrichment
src/personalize.js  Claude writes each email
src/mailer.js       Resend send + compliance footer/headers
src/suppression.js  opt-out list, honored every run
.env.example        config template
```
