// Outreach Engine — pull leads, write emails, send (or dry-run), report everything.
//
//   node index.js          -> DRY RUN. Pulls + writes + prints. Sends nothing.
//   node index.js --send   -> actually sends. Requires every key to be set.
//
import { readFileSync, existsSync, writeFileSync } from "node:fs";
import { getLeads } from "./src/apollo.js";
import { writeEmail } from "./src/personalize.js";
import { sendEmail, previewText } from "./src/mailer.js";
import { loadSuppressed, suppress } from "./src/suppression.js";

// --- tiny .env loader (no dependency) -----------------------
function loadEnv() {
  if (!existsSync(".env")) return;
  for (const line of readFileSync(".env", "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let v = m[2].replace(/^["']|["']$/g, "");
    if (!process.env[m[1]]) process.env[m[1]] = v;
  }
}
loadEnv();

const LIVE = process.argv.includes("--send");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const list = (s) => (s || "").split(",").map((x) => x.trim()).filter(Boolean);

const cfg = {
  apolloKey: process.env.APOLLO_API_KEY,
  anthropicKey: process.env.ANTHROPIC_API_KEY,
  model: process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6",
  resendKey: process.env.RESEND_API_KEY,
  from: process.env.FROM,
  replyTo: process.env.REPLY_TO,
  companyName: process.env.COMPANY_NAME,
  physicalAddress: process.env.PHYSICAL_ADDRESS,
  unsubscribeEmail: process.env.UNSUBSCRIBE_EMAIL,
  // Deployed Vercel service (optional but recommended):
  unsubscribeUrl: process.env.UNSUBSCRIBE_URL,            // e.g. https://your-app.vercel.app/unsubscribe
  unsubscribeSecret: process.env.UNSUBSCRIBE_SECRET,      // must match the Vercel app
  suppressApiUrl: process.env.SUPPRESS_API_URL,           // e.g. https://your-app.vercel.app/api/suppressed
  suppressApiSecret: process.env.SUPPRESS_API_SECRET,     // must match the Vercel app
  maxLeads: parseInt(process.env.MAX_LEADS || "25", 10),
  delay: parseInt(process.env.SEND_DELAY_SECONDS || "8", 10) * 1000,
};
const target = {
  titles: list(process.env.TARGET_TITLES),
  keywords: list(process.env.TARGET_KEYWORDS),
  locations: list(process.env.TARGET_LOCATIONS),
};
const senderPitch =
  process.env.SENDER_PITCH ||
  `${cfg.companyName} helps companies like the recipient's get more booked calls.`;

// --- preflight: refuse to run live without compliance fields ---
function requireFields(fields) {
  const missing = fields.filter((f) => !cfg[f]);
  if (missing.length) {
    console.error(`\nMissing required config: ${missing.join(", ")}. Fill these in .env`);
    process.exit(1);
  }
}
requireFields(["apolloKey", "anthropicKey"]);
if (LIVE) {
  requireFields(["resendKey", "from", "companyName", "physicalAddress", "unsubscribeEmail"]);
}

function bar() { console.log("─".repeat(56)); }

async function main() {
  bar();
  console.log(LIVE ? "OUTREACH ENGINE — LIVE SEND" : "OUTREACH ENGINE — DRY RUN (nothing will be sent)");
  bar();

  console.log("Pulling leads from Apollo…");
  let leads = await getLeads(cfg.apolloKey, target, cfg.maxLeads);
  console.log(`  ${leads.length} leads with usable emails.`);

  console.log("Checking opt-out list (local + cloud)…");
  const suppressed = await loadSuppressed(cfg);
  const before = leads.length;
  leads = leads.filter((l) => !suppressed.has(l.email.toLowerCase()));
  if (before - leads.length) console.log(`  ${before - leads.length} skipped (unsubscribed / bounced / complained).`);

  const results = [];
  for (const [i, lead] of leads.entries()) {
    console.log(`\n[${i + 1}/${leads.length}] ${lead.name} <${lead.email}> · ${lead.title} @ ${lead.company}`);
    const { subject, body } = await writeEmail(cfg.anthropicKey, cfg.model, lead, { senderPitch });
    console.log(`  Subject: ${subject}`);

    if (!LIVE) {
      console.log("  --- email preview ---");
      console.log(previewText(cfg, lead, body).split("\n").map((l) => "  | " + l).join("\n"));
      results.push({ ...lead, subject, status: "DRY_RUN", id: "", error: "" });
      continue;
    }

    try {
      const id = await sendEmail(cfg, lead, subject, body);
      console.log(`  SENT ✓  id=${id}`);
      results.push({ ...lead, subject, status: "SENT", id, error: "" });
    } catch (e) {
      console.log(`  FAILED ✗  ${e.message}`);
      results.push({ ...lead, subject, status: "FAILED", id: "", error: e.message });
    }
    if (i < leads.length - 1) await sleep(cfg.delay);
  }

  // --- report: CSV + console summary ("lets me know all the info") ---
  const cols = ["name", "email", "company", "title", "subject", "status", "id", "error"];
  const csv = [cols.join(",")]
    .concat(results.map((r) => cols.map((c) => `"${String(r[c] || "").replace(/"/g, '""')}"`).join(",")))
    .join("\n");
  const fname = `report-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.csv`;
  writeFileSync(fname, csv);

  const sent = results.filter((r) => r.status === "SENT").length;
  const failed = results.filter((r) => r.status === "FAILED").length;
  bar();
  console.log("SUMMARY");
  console.log(`  Leads processed : ${results.length}`);
  if (LIVE) {
    console.log(`  Sent            : ${sent}`);
    console.log(`  Failed          : ${failed}`);
  } else {
    console.log(`  Mode            : DRY RUN — re-run with --send to actually send`);
  }
  console.log(`  Report saved    : ${fname}`);
  bar();
}

main().catch((e) => { console.error("\nFatal:", e.message); process.exit(1); });
