# Outreach System

Two connected parts:

- **`sender/`** — runs on your machine (or a server you control). Pulls leads from Apollo, writes a personalized email per lead with Claude, and sends through Resend. Dry-run by default; sends only with `--send`.
- **`suppression-service/`** — deploys to Vercel. A one-click unsubscribe page, a Resend bounce/complaint webhook, and a shared opt-out list the sender syncs from before every run.

Together they form a loop: a recipient unsubscribes / bounces / complains → it's recorded in the cloud store → the sender pulls that list before the next run → that address is never emailed again.

## What it does NOT do

No SMS/texting. Cold-texting people who never opted in violates the US TCPA. This system is email-only by design.

## Order of operations

1. **Deploy the suppression service** (see `suppression-service/README.md`):
   ```bash
   cd suppression-service
   vercel login        # opens your browser
   vercel deploy        # or: push to GitHub and import in the Vercel dashboard
   ```
   Then add a KV store, set `UNSUBSCRIBE_SECRET` / `SUPPRESS_API_SECRET` / `RESEND_WEBHOOK_SECRET`, and point a Resend webhook at `/api/webhook`.

2. **Configure the sender** (see `sender/README.md`):
   ```bash
   cd sender
   cp .env.example .env   # fill in keys + paste your deployed Vercel URL + the SAME secrets
   node index.js          # dry run — prints the exact emails, sends nothing
   node index.js --send   # sends for real, writes a report CSV
   ```

The `UNSUBSCRIBE_SECRET` and `SUPPRESS_API_SECRET` must be **identical** in both `.env` files — that's how the two halves trust each other.

## Two ways to send

- **On-demand (the CLI in `sender/`):** you run `node index.js --send` when you want a batch to go. Good while you're dialing in copy and targeting.
- **Fully automatic (the cron in `suppression-service/`):** Vercel Cron calls `/api/cron` on a schedule and sends a small capped batch each time, with no one at the keyboard. It's **off until you set `AUTOSEND_ENABLED=true`**. See `suppression-service/README.md` → "Autonomous background sender".

Both share the same safety rails: hard daily cap, dedupe so nobody is emailed twice, suppression of opt-outs/bounces/complaints, and compliant unsubscribe + address on every email. Running unattended means no human reads each email before it sends — keep the daily cap low and check the Vercel logs, especially the first week.

Each project has its own README with full detail.
