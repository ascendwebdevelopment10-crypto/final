# Outreach Suppression Service (Vercel)

The always-on web half of the outreach system. Three jobs:

1. **`/unsubscribe`** — a one-click opt-out page. The link in every email points here. One click records the opt-out and shows a confirmation. Works with Gmail/Yahoo one-click headers too.
2. **`/api/webhook`** — receives Resend events and auto-suppresses anyone who **bounces** or files a **spam complaint**, plus Resend unsubscribe events. Signature-verified.
3. **`/api/suppressed`** — a secret-protected list the sender pulls before each run, so locally-triggered sends honor every opt-out recorded here.

All three share one store (a Redis set called `suppressed`).

## Deploy

1. **Add a store.** In the Vercel project → **Storage** → add **Vercel KV** (or Upstash Redis). This injects `KV_REST_API_URL` and `KV_REST_API_TOKEN` automatically. Free tier is plenty.
2. **Set env vars** (Project → Settings → Environment Variables):
   - `UNSUBSCRIBE_SECRET` — any long random string. **Must match** the sender's `.env`.
   - `SUPPRESS_API_SECRET` — another long random string. **Must match** the sender's `.env`.
   - `RESEND_WEBHOOK_SECRET` — you get this in the next step; add it after.
3. **Redeploy** so the env vars take effect.
4. **Point Resend at the webhook.** Resend dashboard → **Webhooks** → add endpoint `https://YOUR-APP.vercel.app/api/webhook`, subscribe to `email.bounced` and `email.complained` (and `contact.unsubscribed` if you use Resend audiences). Copy the signing secret (`whsec_…`) into `RESEND_WEBHOOK_SECRET` and redeploy.

## Wire the sender to it

In the **sender's** `.env`, set:

```
UNSUBSCRIBE_URL=https://YOUR-APP.vercel.app/unsubscribe
SUPPRESS_API_URL=https://YOUR-APP.vercel.app/api/suppressed
UNSUBSCRIBE_SECRET=...      # same value as here
SUPPRESS_API_SECRET=...     # same value as here
```

Now opt-outs flow in a loop: recipient clicks unsubscribe (or bounces/complains) → recorded in the
store → the sender pulls the list before the next run → that address is never emailed again.

## Endpoints

| Route | Method | Purpose |
|---|---|---|
| `/unsubscribe?e=<email>&t=<token>` | GET | Human opt-out page |
| `/unsubscribe?e=<email>&t=<token>` | POST | Mail-client one-click opt-out |
| `/api/webhook` | POST | Resend bounce/complaint events (signed) |
| `/api/suppressed?key=<secret>` | GET | Opt-out list for the sender |

## Notes

- No build step, no dependencies — just Node serverless functions.
- The webhook rejects unsigned/forged requests once `RESEND_WEBHOOK_SECRET` is set. Set it.
- The sender still **sends on a command you run**, not automatically. That checkpoint is intentional — it protects your domain reputation. This service just makes sure opt-outs are always respected.

---

## Autonomous background sender (cron)

`/api/cron` is the hands-off sender. Vercel Cron calls it on a schedule; each run sends a small,
capped batch and stops. It is **off until you set `AUTOSEND_ENABLED=true`**.

What each run does:
1. Bails unless `AUTOSEND_ENABLED=true` and the request carries your `CRON_SECRET`.
2. Stops if the `DAILY_CAP` for today is already used up.
3. Searches Apollo (free), skips anyone already **seen / contacted / suppressed**, and enriches only NEW people (so credits are never spent twice).
4. Writes each email with Claude and sends `BATCH_SIZE` of them through Resend, spaced by `SEND_DELAY_SECONDS`.
5. Records who it contacted and how many it sent today. Results show in the Vercel runtime logs.

### Turn it on
1. Add the sending env vars from `.env.example` (Apollo / Anthropic / Resend / FROM / CAN-SPAM fields / targeting).
2. Set `CRON_SECRET` to a long random string and `AUTOSEND_ENABLED=true`.
3. Redeploy. The schedule in `vercel.json` registers automatically.

### Schedule + plan
- Default schedule is **once daily** (`0 15 * * *`, 15:00 UTC) so it deploys on any plan.
- **Vercel Hobby** allows only one cron run per day, and its terms prohibit commercial use — for a real sending program you want **Pro** ($20/mo).
- On **Pro**, switch to frequent small batches for better deliverability, e.g. every 20 min during business hours:
  `"schedule": "*/20 13-21 * * 1-5"` (13:00–21:00 UTC ~= 9am–5pm ET, weekdays) with `BATCH_SIZE=3`.
  Cron times are **UTC only** — convert your local hours.

### Test it before trusting it
Trigger a run by hand (this respects the same guards):
```bash
curl -H "Authorization: Bearer YOUR_CRON_SECRET" https://your-app.vercel.app/api/cron
```
Start with `AUTOSEND_ENABLED=false` (returns "skipped"), then `DAILY_CAP=2`, watch the logs, read the
two emails that land, and only then raise the cap. Warm the domain up before scaling.

### The honest tradeoff
This runs unattended, so nobody eyes each email before it goes. The compliance + dedupe + caps keep it
from becoming spam, but they don't judge whether the *copy* is good or the *targeting* is right on a given
day. Check the logs regularly, especially the first week, and keep the cap low until you trust the output.
